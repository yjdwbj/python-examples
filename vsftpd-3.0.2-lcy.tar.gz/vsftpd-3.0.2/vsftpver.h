#ifndef VSF_VERSION_H
#define VSF_VERSION_H

#define VSF_VERSION "3.0.2"

#endif /* VSF_VERSION_H */

